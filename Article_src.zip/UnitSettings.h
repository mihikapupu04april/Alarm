//---------------------------------------------------------------------------

#ifndef UnitSettingsH
#define UnitSettingsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFormSettings : public TForm
{
__published:	// IDE-managed Components
        TEdit *EditCom;
        TEdit *EditBaud;
        TButton *ButtonCheck;
        TEdit *EditStatus;
        TLabel *LabelPort;
        TLabel *LabelBaud;
        void __fastcall ButtonCheckClick(TObject *Sender);
        void __fastcall EditBaudKeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
        __fastcall TFormSettings(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormSettings *FormSettings;
//---------------------------------------------------------------------------
#endif
