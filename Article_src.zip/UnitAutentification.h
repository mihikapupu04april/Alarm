//---------------------------------------------------------------------------

#ifndef UnitAutentificationH
#define UnitAutentificationH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormAutentification : public TForm
{
__published:	// IDE-managed Components
        TEdit *EditLogin;
        TButton *ButtonCheck;
        TLabel *LabelLogin;
        TEdit *EditPassword;
        TLabel *LabelPassword;
        TPanel *PanelStatus;
        TTimer *TimerMain;
        void __fastcall ButtonCheckClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall TimerMainTimer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormAutentification(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormAutentification *FormAutentification;
//---------------------------------------------------------------------------
#endif
