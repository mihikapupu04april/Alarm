///////////////////////////////////////////////////////////////////////
//
//	ComPort.cpp: implementation of the CComPort class
//
//	Author: Jurgis Armanavichius
//
//	Based on original CSerialPort class by Remon Spekreijse (thank you)
//
///////////////////////////////////////////////////////////////////////

#include "ComPort.h"

class CComPort
{
public:
	CComPort();
	virtual ~CComPort();

	void PresetComParameters(DWORD baud,BYTE databits,BYTE parity,BYTE stopbits);
	BOOL OpenCom(LPCTSTR lpPortName);
	BOOL CloseCom();
	BOOL GetByte(LPBYTE rByte,DWORD dwMilliseconds);
	BOOL PutByte(BYTE wByte);
	DWORD ReadBlock(LPBYTE lpBuffer,DWORD nMax);
	BOOL WriteBlock(LPBYTE lpBuffer,DWORD dwBufferLength);
	BOOL GetOpenedStatus(void);
        BOOL PurgeCom();

protected:
	HANDLE	m_hCommPort;
	BOOL	m_bOpened;
	DWORD	m_Baud;
	BYTE	m_DataBits;
	BYTE	m_Parity;
	BYTE	m_StopBits;
};

//////////////////////////////////////////////////////////////////////
// CComPort class: com_port
//////////////////////////////////////////////////////////////////////

CComPort com_port;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComPort::CComPort()
{
	m_bOpened  = FALSE;
	m_Baud	   = CBR_4800;
	m_DataBits = 8;
	m_Parity   = NOPARITY;
	m_StopBits = ONESTOPBIT;
}


CComPort::~CComPort()
{
	CloseCom();
}

void CComPort::PresetComParameters(DWORD baud,BYTE databits,BYTE parity,BYTE stopbits)
{
	m_Baud     = baud;
	m_DataBits = databits;
	m_Parity   = parity;
	m_StopBits = stopbits;
}

BOOL CComPort::OpenCom(LPCTSTR lpPortName)
{
	if(m_bOpened) return FALSE;	// we are already opened, so OpenCom failed

	BOOL fSuccess;
	DCB  dcb;

	m_hCommPort = CreateFile(lpPortName,
		GENERIC_READ | GENERIC_WRITE,
		0,		// exclusive access
		NULL,	// no security attrs
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
		);


	if(m_hCommPort == INVALID_HANDLE_VALUE) return FALSE;	// OpenCom failed

//	Setup new connection:

	GetCommState(m_hCommPort, &dcb);

	dcb.BaudRate = m_Baud;
	dcb.ByteSize = m_DataBits;
	dcb.Parity   = m_Parity;
	dcb.StopBits = m_StopBits;
	dcb.fOutxDsrFlow = 0;	// we don't need handshake
	dcb.fDtrControl  = 0;
	dcb.fOutxCtsFlow = 0;
	dcb.fRtsControl  = 0;
	dcb.fBinary = TRUE ;
	dcb.fParity = TRUE ;

	fSuccess = SetCommState(m_hCommPort, &dcb);


        COMMTIMEOUTS commtimeouts;
        GetCommTimeouts(m_hCommPort,&commtimeouts);
        typedef struct _COMMTIMEOUTS
        {
        DWORD ReadIntervalTimeout;
        DWORD ReadTotalTimeoutMultiplier;
        DWORD ReadTotalTimeoutConstant;
        DWORD WriteTotalTimeoutMultiplier;
        DWORD WriteTotalTimeoutConstant;
        }
        COMMTIMEOUTS,*LPCOMMTIMEOUTS;

        //commtimeouts.ReadIntervalTimeout=1000;
        commtimeouts.ReadTotalTimeoutConstant=200;

        SetCommTimeouts(m_hCommPort,&commtimeouts);



	if(!fSuccess) return FALSE;	// Can't SetCommState -- OpenCom failed

	PurgeComm(m_hCommPort,PURGE_TXABORT | PURGE_RXABORT |
						  PURGE_TXCLEAR | PURGE_RXCLEAR );	// Clean up COM port

	m_bOpened = TRUE;
	return TRUE;	// OpenCom OK
}

BOOL CComPort::CloseCom()
{
	if(m_bOpened) {
		m_bOpened = FALSE ;
		PurgeComm(m_hCommPort,PURGE_TXABORT | PURGE_RXABORT |
							  PURGE_TXCLEAR | PURGE_RXCLEAR );	// Clean up COM port
		CloseHandle(m_hCommPort) ;
	}
	return TRUE;
}

BOOL CComPort::WriteBlock(LPBYTE lpBuffer, DWORD dwBufferLength)
{
	DWORD dwBytesWritten;
	BOOL  bResult;

	if (!m_bOpened) return FALSE;	// we are not connected

	bResult = WriteFile(m_hCommPort,lpBuffer,dwBufferLength,&dwBytesWritten,NULL);

	if(!bResult) return FALSE;

	return TRUE;
}

DWORD CComPort::ReadBlock(LPBYTE lpBuffer,DWORD nMax)
{
   BOOL       fReadStat ;
   COMSTAT    ComStat ;
   DWORD      dwErrorFlags;
   DWORD      dwLength;

   if(!m_bOpened) return (DWORD)-1;	// we are not connected

   // get number of bytes in queue
   if (ClearCommError( m_hCommPort, &dwErrorFlags, &ComStat )) {
	   dwLength = 1;//!!!!!!!!!!!!!!min( (DWORD) nMax, ComStat.cbInQue ) ;
   }
   else {
	   dwLength=0;
   }

   if(dwLength > 0) {
		fReadStat = ReadFile(m_hCommPort,lpBuffer,dwLength,&dwLength,NULL);
		if(!fReadStat) {
			dwLength = 0;
			ClearCommError(m_hCommPort,&dwErrorFlags,&ComStat) ;
		}
   }
   return dwLength;
}

#define SLEEP_TIME		10

BOOL CComPort::GetByte(LPBYTE rByte,DWORD dwMilliseconds)
{
BYTE  byt;

ReadBlock(&byt,1);
*rByte = byt;

return byt;
}

BOOL CComPort::PutByte(BYTE wByte)
{
	return WriteBlock(&wByte,1);
}

BOOL CComPort::GetOpenedStatus(void)
{
	return m_bOpened;
}


BOOL CComPort::PurgeCom()
{
PurgeComm(m_hCommPort,PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR );	// Clean up COM port

return TRUE;
}


//////////////////////////////////////////////////////////////////////
//
//	User interface routines to ComPort class
//
//////////////////////////////////////////////////////////////////////

void ComPort_PresetParameters(DWORD baud,BYTE databits,BYTE parity,BYTE stopbits)
{
com_port.PresetComParameters(baud,databits,parity,stopbits);
}

BOOL ComPort_Open(char *name)
{
return com_port.OpenCom(name);
}

void ComPort_Close(void)
{
  com_port.CloseCom();
}

BOOL ComPort_PutByte(BYTE byt)
{
  return com_port.PutByte(byt);
}

int  ComPort_GetByte(DWORD dwMilliseconds)
{
  BYTE byt;

  if(com_port.GetByte(&byt,dwMilliseconds))
    return byt;
  else
    return 0;
}

BOOL ComPort_GetOpenedStatus(void)
{
  return com_port.GetOpenedStatus();
}

void ComPort_PurgeCom(void)
{
com_port.PurgeCom();
}
