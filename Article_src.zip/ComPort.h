//////////////////////////////////////////////////////////////////////
//
// ComPort.h: interface for the CComPort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_COMPORT_H_)
//#define _COMPORT_H_

#include <windows.h>

void ComPort_PresetParameters(DWORD baud,BYTE databits,BYTE parity,BYTE stopbits);
BOOL ComPort_Open(char *name);
void ComPort_Close(void);
BOOL ComPort_PutByte(BYTE byt);
int  ComPort_GetByte(DWORD dwMilliseconds);
BOOL ComPort_GetOpenedStatus(void);
void ComPort_PurgeCom(void);

#endif // !defined(_COMPORT_H_)
