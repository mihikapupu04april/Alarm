//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UnitAutentification.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormAutentification *FormAutentification;

extern Decline();
extern Access();
//---------------------------------------------------------------------------
__fastcall TFormAutentification::TFormAutentification(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormAutentification::ButtonCheckClick(TObject *Sender)
{
        AnsiString login="Piligrim";
        AnsiString password="1111";

        if(login==EditLogin->Text)
        {
                if(password==EditPassword->Text)
                {
                        FormAutentification->PanelStatus->Color=clGreen;
                        Access();
                }
                else
                {
                        FormAutentification->PanelStatus->Color=clRed;Decline();
                }
        }
        else
        {
                FormAutentification->PanelStatus->Color=clRed;Decline();
        }

        FormAutentification->TimerMain->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TFormAutentification::FormClose(TObject *Sender, TCloseAction &Action)
{
FormAutentification->EditPassword->Text="";
FormAutentification->EditLogin->Text="";
}
//---------------------------------------------------------------------------
void __fastcall TFormAutentification::TimerMainTimer(TObject *Sender)
{
FormAutentification->Close();
FormAutentification->TimerMain->Enabled=false;
}
//---------------------------------------------------------------------------



