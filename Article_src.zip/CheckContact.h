//---------------------------------------------------------------------------
#ifndef CheckContactH
#define CheckContactH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
        TPanel *PanelMain;
        TTimer *TimerMain;
        TMainMenu *MainMenu;
        TMenuItem *ProgramSettings1;
        TMenuItem *Help1;
        TButton *ButtonStart;
        TButton *ButtonStop;
        TLabel *LabelStatus;
        TMenuItem *Quit1;
        TMenuItem *Autentification1;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall ProgramSettings1Click(TObject *Sender);
        void __fastcall MainMenuChange(TObject *Sender, TMenuItem *Source,
          bool Rebuild);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ButtonStartClick(TObject *Sender);
        void __fastcall ButtonStopClick(TObject *Sender);
        void __fastcall Quit1Click(TObject *Sender);
        void __fastcall Autentification1Click(TObject *Sender);
        void __fastcall Help1Click(TObject *Sender);
public:		// User declarations
        __fastcall TFormMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
