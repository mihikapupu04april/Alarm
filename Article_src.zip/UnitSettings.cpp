//---------------------------------------------------------------------------
#include "ComPort.h"
#include "mmsystem.h"

#include <vcl.h>
#pragma hdrstop

#include "UnitSettings.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormSettings *FormSettings;
//---------------------------------------------------------------------------
__fastcall TFormSettings::TFormSettings(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormSettings::ButtonCheckClick(TObject *Sender)
{
	//checking of the edits "emptiness"
	if(EditCom->Text.IsEmpty())
	{
		EditCom->Text="Com1";
	}

	if(EditBaud->Text.IsEmpty())
	{
		EditBaud->Text="9600";
	}

	//to close the port
	ComPort_Close();

	//entering the number of the comport
	AnsiString ComPort=EditCom->Text;
	char *ComP = ComPort.c_str();

	//entering the baudrate of the comport
	AnsiString BaudRate=EditBaud->Text;
	unsigned long Baud = BaudRate.ToDouble();

	BOOL bOpened;
	ComPort_PresetParameters(Baud,8,NOPARITY,ONESTOPBIT);	// optional function
	bOpened = ComPort_Open(ComP);

	if(bOpened)
	{
		EditStatus->Text="Ready";

		//wellcome note
		DWORD fdwSound = SND_ASYNC | SND_FILENAME;
		PlaySound("sounds/wellcome.wav",NULL, fdwSound);

		FormSettings->Close();
	}
        else
	{
		EditStatus->Text="Bussy";

		//error note
		DWORD fdwSound = SND_ASYNC | SND_FILENAME;
		PlaySound("sounds/error.wav",NULL, fdwSound);
	}
}
//---------------------------------------------------------------------------
void __fastcall TFormSettings::EditBaudKeyPress(TObject *Sender, char &Key)
{
	//allow only digits, without symbols
	if ((Key < '0' || Key > '9') && Key != 8) Key= 0;
}
//---------------------------------------------------------------------------



