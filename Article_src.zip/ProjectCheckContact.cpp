//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("CheckContact.cpp", FormMain);
USEFORM("UnitSettings.cpp", FormSettings);
USEFORM("UnitAutentification.cpp", FormAutentification);
USEFORM("UnitAbout.cpp", FormAbout);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TFormMain), &FormMain);
                 Application->CreateForm(__classid(TFormSettings), &FormSettings);
                 Application->CreateForm(__classid(TFormAutentification), &FormAutentification);
                 Application->CreateForm(__classid(TFormAbout), &FormAbout);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
