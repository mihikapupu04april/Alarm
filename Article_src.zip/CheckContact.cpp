#pragma hdrstop
#include <vcl.h>
#include<math.h>
#include "ComPort.h"
#include <mmsystem.h>
#include "CheckContact.h"

#include "UnitAutentification.h"
#include "UnitSettings.h"
#include "UnitAbout.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TFormMain *FormMain;
static AnsiString ComPort;

void Decline(void)
{
	FormMain->PanelMain->Hide();
	FormMain->ButtonStart->Hide();
	FormMain->ButtonStop->Hide();
}

void Access(void)
{
	FormMain->PanelMain->Show();
	FormMain->ButtonStart->Show();
	FormMain->ButtonStop->Show();
}

//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ProgramSettings1Click(TObject *Sender)
{
	FormMain->LabelStatus->Caption="Waiting";
	FormMain->TimerMain->Enabled=false;
	FormSettings->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::MainMenuChange(TObject *Sender, TMenuItem *Source,
      bool Rebuild)
{
	//FormMain->TimerMain->Enabled=false;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::FormCreate(TObject *Sender)
{
	Decline();

	FormMain->TimerMain->Enabled=false;
	FormMain->PanelMain->Caption="Set up the program";
	FormMain->LabelStatus->Caption="Waiting";
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonStartClick(TObject *Sender)
{
	FormMain->LabelStatus->Caption="Working";
	FormMain->TimerMain->Enabled=true;

	ComPort_PurgeCom();

	ComPort_PutByte(0xff);

	if(ComPort_GetByte(1))
	{
		FormMain->PanelMain->Caption="All right!";
		FormMain->Color=0x000080FF;
	}
	else
	{
		FormMain->PanelMain->Caption="ALARM!!!";

		//ALARM!!!
		DWORD fdwSound = SND_ASYNC | SND_FILENAME;
		PlaySound("sounds/ALARM.wav",NULL, fdwSound);

		FormMain->Color=clRed;
	}
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonStopClick(TObject *Sender)
{
	FormMain->LabelStatus->Caption="Waiting";
	FormMain->TimerMain->Enabled=false;
	FormMain->PanelMain->Caption="Waiting";
	FormMain->Color=0x000080FF;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::Autentification1Click(TObject *Sender)
{
	FormAutentification->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::Help1Click(TObject *Sender)
{
	FormAbout->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::FormClose(TObject *Sender, TCloseAction &Action)
{
	ComPort_Close();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::Quit1Click(TObject *Sender)
{
	FormMain->Close();
}
//---------------------------------------------------------------------------


